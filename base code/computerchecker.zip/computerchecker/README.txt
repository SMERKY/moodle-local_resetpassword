Computer Checker for Moodle.

Package name: local_computerchecker
Copyright: 2013 Aaron Leggett - LearningWorks Ltd.
Authors: Bas Brands and Gavin Henrick.
License: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later


ABOUT

This plugin adds a checker to your Moodle to check the versions of browser plugins.
The plugin checks your browser and alerts with a popup if your versions are not up to set standard.
Then a cookie is set so the code does not run again.

INSTALLATION

Install this plugin in your /local folder
Then login as an admin and go to
Site Administration -> Notifications

This should trigger the installation process


CONFIGURATION

To configure this plugin go to:
Site Administration -> Plugins -> Local Plugins -> Computer Checker